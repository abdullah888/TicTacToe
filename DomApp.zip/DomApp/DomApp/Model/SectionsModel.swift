//
//  SectionsModel.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Foundation
import Firebase

class SectionsModel :Identifiable {
    
    var ID : String?
    var SectionName : String?

   
   
    init(ID : String ,  SectionName : String ) {
        self.ID = ID
        self.SectionName = SectionName
       
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.SectionName = Dictionary["SectionName"] as? String

       
        
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["SectionName"] = self.SectionName as AnyObject

       
        
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Sections").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class SectionsApi {
    
    
    static func GetSections(ID : String, completion : @escaping (_ Sections : SectionsModel)->()){
        
        Firestore.firestore().collection("Sections").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = SectionsModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllSections(completion : @escaping (_ Sections : SectionsModel)->()){
        Firestore.firestore().collection("Sections").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = SectionsModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}



