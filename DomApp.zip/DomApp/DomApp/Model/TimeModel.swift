//
//  TimeModel.swift
//  DomApp
//
//  Created by abdullah on 10/02/1445 AH.
//

import SwiftUI
import Foundation
import Firebase

class TimeModel :Identifiable {
    
    var ID : String?
    var Time1 : Date?
    var Time2 : Date?
    var Time3 : Date?
    var Time4 : Date?
    var Time5 : Date?
    var Time6 : Date?
    var Time7 : Date?
    var Time8 : Date?
   
   
    init(ID : String , Time1 : Date , Time2 : Date , Time3 : Date , Time4 : Date  , Time5 : Date , Time6 : Date , Time7 : Date , Time8 : Date   ) {
        self.ID = ID
        self.Time1 = Time1
        self.Time2 = Time2
        self.Time3 = Time3
        self.Time4 = Time4
        self.Time5 = Time5
        self.Time6 = Time6
        self.Time7 = Time7
        self.Time8 = Time8
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.Time1 = Dictionary["Time1"] as? Date
        self.Time2 = Dictionary["Time2"] as? Date
        self.Time3 = Dictionary["Time3"] as? Date
        self.Time4 = Dictionary["Time4"] as? Date
        self.Time5 = Dictionary["Time5"] as? Date
        self.Time6 = Dictionary["Time6"] as? Date
        self.Time7 = Dictionary["Time7"] as? Date
        self.Time8 = Dictionary["Time8"] as? Date
       
        
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["Time1"] = self.Time1 as AnyObject
        New["Time2"] = self.Time2 as AnyObject
        New["Time3"] = self.Time3 as AnyObject
        New["Time4"] = self.Time4 as AnyObject
        New["Time5"] = self.Time5 as AnyObject
        New["Time6"] = self.Time6 as AnyObject
        New["Time7"] = self.Time7 as AnyObject
        New["Time8"] = self.Time8 as AnyObject
        
       
        
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Times").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class TimeApi {
    
    
    static func GetTime(ID : String, completion : @escaping (_ Time : TimeModel)->()){
        
        Firestore.firestore().collection("Times").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = TimeModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllTimes(completion : @escaping (_ Times : TimeModel)->()){
        Firestore.firestore().collection("Times").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = TimeModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}



