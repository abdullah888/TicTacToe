//
//  TimeViewModel.swift
//  DomApp
//
//  Created by abdullah on 10/02/1445 AH.
//

import SwiftUI
import Firebase

class TimeViewModel : ObservableObject{
  
    //Modell
    @Published var Times: [TimeModel] = []

  
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
    init() {
        fetchData()
    }

    
    
    func GetTime(){
        ref.collection("Times").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    TimeApi.GetTime(ID: doc.document.documentID) { time in
                        self.Times.append(time)
                    }
                }
            }
        }
    }
    
    func NewGetTime() {
         
         let db = Firestore.firestore()
     
        db.collection("Times").addSnapshotListener { (snap, err) in
            
            if err != nil{
                
                print((err?.localizedDescription)!)
                return
            }
            
            for i in snap!.documentChanges{
                
                if i.type == .added{
                    
                    let id = i.document.documentID
                    let Time1 = i.document.get("Time1") as! Timestamp
                    let Time2 = i.document.get("Time2") as! Timestamp
                    let Time3 = i.document.get("Time3") as! Timestamp
                    let Time4 = i.document.get("Time4") as! Timestamp
                    let Time5 = i.document.get("Time5") as! Timestamp
                    let Time6 = i.document.get("Time6") as! Timestamp
                    let Time7 = i.document.get("Time7") as! Timestamp
                    let Time8 = i.document.get("Time8") as! Timestamp
                    self.Times.append(TimeModel(ID: id, Time1: Time1.dateValue(), Time2: Time2.dateValue(), Time3: Time3.dateValue(), Time4: Time4.dateValue(), Time5: Time5.dateValue(), Time6: Time6.dateValue(), Time7: Time7.dateValue(), Time8: Time8.dateValue()))
                    }
                }
            }
        }
        

    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Times").getDocuments { (snap, err) in
            
            guard let TimeData = snap else{return}
            
            self.Times = TimeData.documents.compactMap({ (doc) -> TimeModel? in
                
                let id = doc.documentID
                let Time1 = doc.get("Time1") as! Timestamp
                let Time2 = doc.get("Time2") as! Timestamp
                let Time3 = doc.get("Time3") as! Timestamp
                let Time4 = doc.get("Time4") as! Timestamp
                let Time5 = doc.get("Time5") as! Timestamp
                let Time6 = doc.get("Time6") as! Timestamp
                let Time7 = doc.get("Time7") as! Timestamp
                let Time8 = doc.get("Time8") as! Timestamp
                return TimeModel(ID: id, Time1: Time1.dateValue(), Time2: Time2.dateValue(), Time3: Time3.dateValue(), Time4: Time4.dateValue(), Time5: Time5.dateValue(), Time6: Time6.dateValue(), Time7: Time7.dateValue(), Time8: Time8.dateValue())
            })
            DispatchQueue.main.async {
                self.Times = self.Times
            }
        }
    }
    
    func deleteTime(id: String){
        let ref = Firestore.firestore()
        
        ref.collection("Times").document(id).delete { (err) in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
        }
    }
    func Delete(){
        Times.forEach { (i) in
            deleteTime(id: i.ID!)
        }
    }
    
}
