//
//  SectionsViewModel.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Firebase

class SectionsViewModel : ObservableObject{
  
    //Modell
    @Published var Sections: [SectionsModel] = []
    @Published  var SectionName = ""
  
  
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
    init() {
        GetSections()
   
    }
// غير مستخدم
    func UploadSections(){
        let db = Firestore.firestore()
        Auth.auth().addStateDidChangeListener { auth, user in
            if let id = user?.uid{
                UserApi.GetUser(ID: id) { User in
                    db.collection("Sections")
                        .document()
                        .setData(["SectionName":self.SectionName]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
                    self.SectionName = ""
                    }
                }
            }
       
        }
    

    func GetSections(){
        ref.collection("Sections").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    SectionsApi.GetSections(ID: doc.document.documentID) { Sections in
                        self.Sections.append(Sections)
                    }
                }
            }
        }
    }
    
    func NewGetSections() {
        
        let db = Firestore.firestore()
        
        db.collection("Sections").addSnapshotListener { (snap, err) in
            
            if err != nil{
                
                print((err?.localizedDescription)!)
                return
            }
            
            for i in snap!.documentChanges{
                
                
                if i.type == .added{
                    
                    let id = i.document.documentID
                    let SectionName = i.document.get("SectionName") as! String
                    self.Sections.append(SectionsModel(ID: id, SectionName: SectionName))
                }
                
            }
        }
    }
     
    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Sections").getDocuments { (snap, err) in
            
            guard let SectionsData = snap else{return}
            
            self.Sections = SectionsData.documents.compactMap({ (doc) -> SectionsModel? in
                
                
                
                let id = doc.documentID
                let SectionName = doc.get("SectionName") as! String
          
                return SectionsModel(ID: id, SectionName: SectionName)

            })
            
            self.Sections = self.Sections
        }
    }
}
