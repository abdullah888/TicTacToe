//
//  MDepartmentIView.swift
//  HMH App
//
//  Created by Asrar on 18/12/1444 AH.
//

import SwiftUI

struct MDepartmentIView: View {
  //  var department = ["LAB","xray","physi"]
    var MDepartmentDetalis: MDepartmentDetalis
    var body: some View {
      
                VStack{
                    
                    Image(MDepartmentDetalis.image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 120 ,height: 120)
                        .background(LinearGradient(gradient: Gradient(colors: [Color(.gray).opacity(0.3),Color(.gray)]), startPoint: .top, endPoint: .bottom))
                        .clipShape(RoundedRectangle(cornerRadius: 20,style: .continuous))
                        .shadow(color: .black.opacity(0.3), radius: 15, x: 0,y: 10)
                    
                    Text(MDepartmentDetalis.name)
                        .font(.headline)
                        .foregroundColor(.purple)
                        .bold()
                    // .shadow(color: .black, radius: 3 ,x: 0, y: 0)
                     //  .padding()
                    
            
        }
        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
              /*  Button(action: {
                  
                }) {
                    Image("LAB")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 150 , height: 150)
                }
                
                
                Image("xray")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 150 , height: 150)
               // Text("Lab department")*/
             
                
                 
            }
        
            
        
         
            
          
                
              
                
                
          
            
            
        }
  

struct MDepartmentIView_Previews: PreviewProvider {
    static var previews: some View {
        MDepartmentIView(MDepartmentDetalis: MDepartmentDetalis.all[0])
    }
}
