//
//  AddTimes.swift
//  DomApp
//
//  Created by abdullah on 10/02/1445 AH.
//

import SwiftUI
import Firebase

struct AddTimes: View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @State var color = Color("Color")
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedDate1 : Date = Date()
    @State private var selectedDate2 : Date = Date()
    @State private var selectedDate3 : Date = Date()
    @State private var selectedDate4 : Date = Date()
    @State private var selectedDate5 : Date = Date()
    @State private var selectedDate6 : Date = Date()
    @State private var selectedDate7 : Date = Date()
    @State private var selectedDate8 : Date = Date()
    @State var DoctorName = ""
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        return formatter
    }()
    var body: some View {
        ZStack{
            VStack{
                VStack{
                    Image("Logo")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 300, height: 300)
                    Text("اضافة طبيب")
                         .font(.title)
                         .fontWeight(.bold)
                         .foregroundColor(self.color)
                         .padding()
                    List{
                        VStack(spacing:10){
                            HStack{
                                DatePicker(selection: $selectedDate1, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("1")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate2, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("2")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate3, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("3")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate4, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("4")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate5, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("5")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate6, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("6")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate7, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("7")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                            HStack{
                                DatePicker(selection: $selectedDate8, in: ...Date.distantFuture, displayedComponents: [.date, .hourAndMinute]) {
                                            Text("8")
                                        
                                                      .colorMultiply(.white)
                                                      .accentColor(.white)
                                }.foregroundColor(Color("Color"))
                                Spacer()
                            }.padding()
                        }
                    }
                    Button(action: {
                        
                        UploadTimes()
                        
                    }) {
                        Text("انشاء")
                            .foregroundColor(.white)
                            .padding(.vertical)
                            .frame(width: UIScreen.main.bounds.width - 50)
                    }
                    .background(Color("Color"))
                    .cornerRadius(8)
                    .padding(.top, 25)
                    
                }
                Spacer()
            }
        }
    }
  
    func UploadTimes(){
        let db = Firestore.firestore()
    
                    db.collection("Times")
                        .document()
                        .setData(["ID":UUID().uuidString,"Time1":self.selectedDate1,"Time2":self.selectedDate2,"Time3":self.selectedDate3,"Time4":self.selectedDate4,"Time5":self.selectedDate5,"Time6":self.selectedDate6,"Time7":self.selectedDate7,"Time8":self.selectedDate8]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
        presentationMode.wrappedValue.dismiss()
        }
}

struct AddTimes_Previews: PreviewProvider {
    static var previews: some View {
        AddTimes()
    }
}
