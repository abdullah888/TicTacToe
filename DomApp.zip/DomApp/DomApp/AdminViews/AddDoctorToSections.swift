//
//  AddDoctorToSections.swift
//  DomApp
//
//  Created by abdullah on 04/02/1445 AH.
//

import SwiftUI
import Firebase

struct AddDoctorToSections: View {
    @StateObject var DoctorToSectionstdata = DoctorToSectionsViewModel()
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var DoctorData = DoctorsViewModel()
    @StateObject var SectionData = SectionsViewModel()
    @StateObject var TimeData = TimeViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedSection = ""
    @State private var selectedDoctor = ""
    @State private var selectedDate  : Date = Date()
    @State private var selectedTime : Date = Date()
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        return formatter
    }()
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section{
                    Picker("اختيار القسم", selection: $selectedSection) {
                        ForEach(SectionData.Sections) { section in
                            Text(section.SectionName!).tag(section.SectionName!)
                            
                        }
                    }.pickerStyle(.segmented)
                    
                    Picker("اختيار الدكتور", selection: $selectedDoctor) {
                        
                        ForEach(DoctorData.Doctors) { doctors in
                            Text(doctors.DoctorName!).tag(doctors.DoctorName!)
                        }
                    }.pickerStyle(.segmented)
                    
                    Picker("اختيار اليوم المناسب", selection: $selectedDate) {
                        
                        ForEach(TimeData.Times) { time in
                            
                            Text(time.Time1!,style: .date).tag(time.Time1!)
                            Text(time.Time2!,style: .date).tag(time.Time2!)
                            Text(time.Time3!,style: .date).tag(time.Time3!)
                            Text(time.Time4!,style: .date).tag(time.Time4!)
                            Text(time.Time5!,style: .date).tag(time.Time5!)
                            Text(time.Time6!,style: .date).tag(time.Time6!)
                            Text(time.Time7!,style: .date).tag(time.Time7!)
                            Text(time.Time8!,style: .date).tag(time.Time8!)
                        }
                    }.pickerStyle(.wheel)
                        .frame(height:60)
                  
                    
                    Picker("اختيار الوقت المناسب", selection: $selectedTime) {
                        
                        ForEach(TimeData.Times) { time in
                            Text(time.Time1!,style: .time).tag(time.Time1!)
                            Text(time.Time2!,style: .time).tag(time.Time2!)
                            Text(time.Time3!,style: .time).tag(time.Time3!)
                            Text(time.Time4!,style: .time).tag(time.Time4!)
                            Text(time.Time5!,style: .time).tag(time.Time5!)
                            Text(time.Time6!,style: .time).tag(time.Time6!)
                            Text(time.Time7!,style: .time).tag(time.Time7!)
                            Text(time.Time8!,style: .time).tag(time.Time8!)
                        }
                    }.pickerStyle(.wheel)
                        .frame(height:60)
                     
                    
                }
                Section{
                    HStack{
                        Spacer()
                        Button {
                            UploadDoctorToSections()
                        } label: {
                            Text("انشاء")
                        }
                        Spacer()
                    }
                }
               
            }
            
       }
   }
    func UploadDoctorToSections(){
        let db = Firestore.firestore()
                    db.collection("DoctorToSections")
                        .document()
                        .setData(["ID":UUID().uuidString,"SectionName":self.selectedSection,"DoctorName":self.selectedDoctor,"Time":self.selectedTime,"date":self.selectedDate]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
       
        presentationMode.wrappedValue.dismiss()
        }
}

struct AddDoctorToSections_Previews: PreviewProvider {
    static var previews: some View {
        AddDoctorToSections()
    }
}
