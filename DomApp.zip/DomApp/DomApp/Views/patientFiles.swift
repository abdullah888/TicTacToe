//
//  patientFiles.swift
//  HMH App
//
//  Created by Asrar on 21/12/1444 AH.
//

import SwiftUI

struct patientFiles: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct patientFiles_Previews: PreviewProvider {
    static var previews: some View {
        patientFiles()
    }
}
