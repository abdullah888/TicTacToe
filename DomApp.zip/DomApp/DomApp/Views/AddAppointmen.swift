//
//  AddAppointmen.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI
import Firebase
struct AddAppointmen: View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var DoctorData = DoctorsViewModel()
    @StateObject var SectionData = SectionsViewModel()
    @StateObject var DoctorToSectionsData = DoctorToSectionsViewModel()
    @State private var selectedSection = ""
    var body: some View {
        ZStack{
            VStack{
                VStack{
                        Section{
                            HStack{
                                Text("اختيار القسم")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("Color"))
                                Spacer()
                            }
                            Picker("", selection: $selectedSection) {
                                ForEach(SectionData.Sections) {
                                    Sections in
                                        Text(Sections.SectionName!).tag(Sections.SectionName!)
                                }
                            }.pickerStyle(.segmented)
                        }.padding()
                    }
                Spacer()
                HStack{
                    Text("بطاقة المراجعة")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color("Color"))
                        .padding()
                    Spacer()
                }
                VStack{
                    ScrollView(.vertical, showsIndicators: false) {
                        ForEach(DoctorToSectionsData.DoctorToSections)  { DoctorToSections in
                            if selectedSection == DoctorToSections.SectionName! {
                                DoctorToSectionCard(DoctorToSection: DoctorToSections)
                            }
                        }
                    }
                }
            }
        }
    }
}

struct AddAppointmen_Previews: PreviewProvider {
    static var previews: some View {
        AddAppointmen()
    }
}





struct DoctorToSectionCard : View {
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var DoctorToSectionsData = DoctorToSectionsViewModel()
    var DoctorToSection : DoctorToSectionsModel
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedDate : Date = Date()
    @State private var selectedTime: Date = Date()
 
    var body: some View {
        VStack{
       
            VStack{
               
                VStack{
                    HStack{
                       
                        Image("doctor")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 50, height: 50)
                            .clipShape(Circle())
                            
                        Text(DoctorToSection.DoctorName!)
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            
                        Spacer()
                        Text(DoctorToSection.SectionName!)
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }.padding()
                    
                VStack{
                 
                    VStack{
                        Picker("اختيار الوقت واليوم", selection: $selectedDate) {
                            
                            ForEach(DoctorToSectionsData.DoctorToSections) { DoctorToSections in
                                if DoctorToSection.DoctorName == DoctorToSections.DoctorName! {
                                    Text(DoctorToSections.date!,style: .date)
                                        .foregroundColor(.white)
                                }
                                
                            }
                        }.pickerStyle(.wheel)
                            .frame(height:60)
                        Picker("اختيار الوقت واليوم", selection: $selectedTime) {
                            
                            ForEach(DoctorToSectionsData.DoctorToSections) { DoctorToSections in
                                if DoctorToSection.DoctorName == DoctorToSections.DoctorName!  {
                                    Text(DoctorToSections.Time!,style: .time)
                                        .foregroundColor(.white)
                                }
                                
                            }
                        }.pickerStyle(.wheel)
                            .frame(height:60)
                        Spacer()
                    }.padding()
                    
                        HStack{
                            Button {
                                UploadAppointment()
                            } label: {
                                Text("حجز موعد")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.red)
                                    .padding()
                            }
                            Spacer()
                        }
                    }
                }
         
            }.frame(width:UIScreen.main.bounds.width - 15,height: 320)
                .background(Color("Color"))
                .cornerRadius(15)
            Spacer()
        }
        
    }
    
    func UploadAppointment(){
        let db = Firestore.firestore()
        
                    db.collection("Appointments")
                        .document()
                        .setData(["ID":UUID().uuidString,"SectionName":DoctorToSection.SectionName!,"Phonenumber":profileDate.userInfo.Phonenumber!,"UserName":profileDate.userInfo.Name!,"AppointmentID":profileDate.userInfo.ID!,"DoctorName":DoctorToSection.DoctorName!,"Time":self.selectedTime,"date": self.selectedDate]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
           
        presentationMode.wrappedValue.dismiss()
        }
}
