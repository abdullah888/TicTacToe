//
//  HomeUIView.swift
//  HMH App
//
//  Created by Asrar on 17/12/1444 AH.
//

import SwiftUI

struct HomeUIView: View {
    @StateObject var locaetiondata = LocationViewModel()
    @ObservedObject var Hospitallocation = LocationManager()
    var image = ["ad_1","ad_2"]
    var body: some View {
        NavigationView{
            ZStack{
                Image("header")
                    .resizable()
                    .scaledToFit()
                   // .ignoresSafeArea()
                    .offset(y: -320)
                VStack{
                    HStack{
                        Button {
                            Hospitallocation.openMapWithAddress()
                        } label: {
                                Image("place")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                        }
                        Text("Welcome patint name ")
                            .font(.title)
                            .bold()
                            .offset(y: 35)
                    }
     
                    TabView{
                        ForEach(image, id: \.self){
                            index in
                            
                            Image(index)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 250 , height: 250)
                        }
                    }
                    
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
                    MDepartmentList(DepList: MDepartmentDetalis.all)
                     }
                
                }
            if locaetiondata.noLocation{
                  
                  Text("Please Enable Location Access In Settings To Further Move On !!!")
                      .foregroundColor(.black)
                      .frame(width: UIScreen.main.bounds.width - 100, height: 120)
                      .background(Color.white)
                      .cornerRadius(10)
                      .frame(maxWidth: .infinity, maxHeight: .infinity)
                      .background(Color.black.opacity(0.3).ignoresSafeArea())
              }
               
          }  .onAppear(perform: {
              
              // calling location delegate....
              locaetiondata.locationManager.delegate = locaetiondata
          })
    }
}

struct HomeUIView_Previews: PreviewProvider {
    static var previews: some View {
        HomeUIView()
    }
}
