//
//  CustomerView.swift
//  HMH App
//
//  Created by Asrar on 14/12/1444 AH.
//

import SwiftUI


@available(iOS 16.0, *)
struct CustomerView: View {
    var body: some View {
       
       
        TabView{
            HomeUIView()
                .tabItem{
                    Label("Home", systemImage: "house")
                }
            patientCard()
                .tabItem{
                    Label("My Card", systemImage: "person")
                }
            AppointmentView()
                .tabItem{
                    Label("Appointment", systemImage: "plus.rectangle")
                }
            patientFiles()
                .tabItem{
                    Label("My Files", systemImage: "heart.text.square.fill")
                }
            Emergency()
                .tabItem{
                    Label("Emergency", systemImage: "house")
                }
            AdminView()
                .tabItem{
                    Label("AdminView", systemImage: "hand.point.up.braille.fill")
                }
            MoreHomView()
                .tabItem{
                    Label("Home", systemImage: "house")
                }
            
        }
        .tint(.purple)

    }
}

struct CustomerView_Previews: PreviewProvider {
    static var previews: some View {
        CustomerView()
    }
}
