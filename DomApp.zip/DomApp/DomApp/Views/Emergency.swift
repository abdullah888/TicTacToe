//
//  Emergency.swift
//  DomApp
//
//  Created by abdullah on 11/01/1445 AH.
//

import SwiftUI
import Firebase

struct Emergency: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var locaetiondata = LocationViewModel()
    var body: some View {
        ZStack{
            VStack{
                List {
                    ForEach(locaetiondata.location) { location in
                        EmergencyCard(location: location, profileDate: profileDate)
                            .buttonStyle(PlainButtonStyle())
                    }.onDelete { (index) in
                        let db = Firestore.firestore()
                        db.collection("Locations").document(self.locaetiondata.location[index.last!].ID!).delete { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                            }
                            self.locaetiondata.location.remove(atOffsets: index)
                        }
                    }
                }
            }
        }.onAppear(){
            locaetiondata.fetchLocationData()
        }
    }
}

struct Emergency_Previews: PreviewProvider {
    static var previews: some View {
        Emergency()
    }
}


struct EmergencyCard :View{
    var location : LocationModel
    @State var showMap = false
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var locationData = LocationViewModel()
    
    var body: some View{
        VStack{
            VStack{
                HStack{
                    Image("hospital")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 50, height: 50)
                    VStack{
                        Text(location.userName!)
                            .font(.headline)
                            .foregroundColor(.red)
                        Text(location.Time!,style: .time)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                    Spacer()
                }
                HStack{
                    Text("Phone: \(profileDate.userInfo.Phonenumber!)")
                        .font(.headline)
                        .foregroundColor(.red)
                    Spacer()
                }
                HStack{
                   Text(location.Location!)
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                    Spacer()
                    Button {
                        locationData.openMapWithAddresss()
                    } label: {
                        Image("place")
                            .resizable()
                            .frame(width: 30, height: 30)
                            
                    }
                }
            }
        }.onAppear(){
                locationData.invalid = false
                locationData.Location = location.Location!
        }
    }
    func generateCurrentTimeStamp () -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy HH:mm"
        return (formatter.string(from: location.Time!) as NSString) as String
    }
    
   
}

