//
//  MoreHomView.swift
//  HMH App
//
//  Created by Asrar on 20/12/1444 AH.
//

import SwiftUI
import Firebase
struct MoreHomView: View {
    @StateObject var DoctorToSectionstdata = DoctorToSectionsViewModel()
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var DoctorData = DoctorsViewModel()
    @StateObject var SectionData = SectionsViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedSection = ""
    @State private var selectedDoctor = ""
    @State private var selectedDate : Date = Date()
    private let dateFormtatter : DateFormatter = {
        let Formtatter = DateFormatter()
        Formtatter.dateStyle = .medium
        return Formtatter
    }()
    var body: some View {
        
        NavigationStack {
            
            Form {
                
            
                Picker("اختيار القسم", selection: $selectedSection) {
                    ForEach(SectionData.Sections) { section in
                        Text(section.SectionName!).tag(section.SectionName!)
                       }
                    }.pickerStyle(.segmented)
                    
                Picker("اختيار الدكتور", selection: $selectedDoctor) {

                        ForEach(DoctorData.Doctors) { doctors in
                            Text(doctors.DoctorName!).tag(doctors.DoctorName!)
                        }
                    }.pickerStyle(.segmented)
                
               
//                DatePicker(selection: $selectedDate, in: ...Date.distantFuture, displayedComponents: .date) {
//                               Text("اختيار التاريخ")
//                    }
                }
            Button {
                UploadDoctorToSections()
            } label: {
                Text("رفع البيانات")
            }

            
            }
        }
    func UploadDoctorToSections(){
        // لايعمل بالصورة الصحيحة
        let db = Firestore.firestore()
                    db.collection("DoctorToSections")
                        .document()
                        .setData(["ID":UUID().uuidString,"SectionName":self.selectedSection,"DoctorName":self.selectedDoctor]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
       
        presentationMode.wrappedValue.dismiss()
        }
    }

struct MoreHomView_Previews: PreviewProvider {
    static var previews: some View {
        MoreHomView()
    }
}
