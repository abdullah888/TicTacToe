//
//  patientCard.swift
//  HMH App
//
//  Created by Asrar on 21/12/1444 AH.
//

import SwiftUI
import Firebase
struct patientCard: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var locaetiondata = LocationViewModel()
    @State private var showingAlert = false
    var body: some View {
        VStack{
            HStack{
                Button {
                    try! Auth.auth().signOut()
                    UserDefaults.standard.set(false, forKey: "status")
                    NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
                } label: {
                    Image("LogOut")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(Color("Color"))
                        .padding()
                }
                Spacer()
                
                    Text(locaetiondata.userLocation == nil ? "": locaetiondata.userAddress)
                    
                        .font(.headline)
                        .foregroundColor(.black)
                        .padding()
                Spacer()
                Button {
                   showingAlert = true
                } label: {
                   
                    Image("ambulance")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .padding()
                }
         
            }
            VStack{
                Image("Logo")
                   .resizable()
                   .aspectRatio(contentMode: .fill)
                   .frame(width: UIScreen.main.bounds.width - 20, height: 250)
                   .cornerRadius(15)
            }
            VStack{
               
                VStack{
                    HStack{
                       
                        Image("doctors_bag")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 50, height: 50)
                            .clipShape(Circle())
                            .padding()
                        Text("Name : \(profileDate.userInfo.Name!)")
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            
                        Spacer()
                    }
                       
                    HStack{
                        Text("Phone Number : \(profileDate.userInfo.Phonenumber!)")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                        Spacer()
                    }
                    HStack{
                        Text("Card Number : \(profileDate.userInfo.CartIDnumber!)")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding()
                        Spacer()
                    }
                }
         
            }.frame(width:UIScreen.main.bounds.width - 15,height: 200)
                .background(Color("Color"))
                .cornerRadius(15)
            Spacer()
            if locaetiondata.noLocation{
                  
                  Text("Please Enable Location Access In Settings To Further Move On !!!")
                      .foregroundColor(.black)
                      .frame(width: UIScreen.main.bounds.width - 100, height: 120)
                      .background(Color.white)
                      .cornerRadius(10)
                      .frame(maxWidth: .infinity, maxHeight: .infinity)
                      .background(Color.black.opacity(0.3).ignoresSafeArea())
              }
        }.onAppear(perform: {
            
            // calling location delegate....
            locaetiondata.locationManager.delegate = locaetiondata
        })
        .onDisappear{
            locaetiondata.locationManager.delegate = locaetiondata
        }
        .alert("مستشفى المدينة الطبي", isPresented: $showingAlert) {
                   Button("الغاء", role: .destructive) {}
                   Button("طلب الطبيب") { }
                   Button("طلب سيارة السعاف") {
                      // UploadLocation()
                   }
                   Button("Stop", role: .cancel) {}
               } message: {
                   Text("سعر طلب الطبيب ٥٠ ريال \n سعر طلب الاسعاف ١٥٠ ريال")
               }
    }
    
    func UploadLocation(){
        let db = Firestore.firestore()
                    db.collection("Locations")
                        .document()
                        .setData(["ID":UUID().uuidString,"Location":self.locaetiondata.userAddress,"Time":Date(),"userName":profileDate.userInfo.Name!,"userID":profileDate.userInfo.ID!]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                            }
        
        presentationMode.wrappedValue.dismiss()
        }
}

struct patientCard_Previews: PreviewProvider {
    static var previews: some View {
        patientCard()
    }
}


