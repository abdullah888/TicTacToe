//
//  DomAppApp.swift
//  DomApp
//
//  Created by abdullah on 01/01/1445 AH.
//

import SwiftUI
import LanguageManagerSwiftUI
import FirebaseCore


class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()

    return true
  }
}

@available(iOS 16.0, *)
@main
struct DomAppApp: App {
    // register app delegate for Firebase setup
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
     var body: some Scene {
         WindowGroup {
             LanguageManagerView(.deviceLanguage){
                 ContentView()
             }
             .transition(.slide)
         }
     }
 }
