//
//  ContentView.swift
//  DomApp
//
//  Created by abdullah on 01/01/1445 AH.
//

import SwiftUI


@available(iOS 16.0, *)
struct ContentView: View {
    var body: some View {
        Cech()
    }
}


@available(iOS 16.0, *)
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
       
            ContentView()
               
           
    }
}
