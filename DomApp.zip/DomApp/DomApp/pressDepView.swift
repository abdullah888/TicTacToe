//
//  pressDepView.swift
//  HMH App
//
//  Created by Asrar on 20/12/1444 AH.
//

import SwiftUI

struct pressDepView: View {
    var MDepartmentDetalis: MDepartmentDetalis
    var body: some View {
        ScrollView{
          
            

        }
        
        .ignoresSafeArea(.container,edges: .top)
        
    }
}

struct pressDepView_Previews: PreviewProvider {
    static var previews: some View {
        
        pressDepView(MDepartmentDetalis: MDepartmentDetalis.all[0])
    }
}
