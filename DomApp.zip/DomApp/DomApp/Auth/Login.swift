//
//  Login.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI
import LanguageManagerSwiftUI

struct Login: View{
    @State var color = Color("Color")
    @State var email = ""
    @State var pass = ""
    @State var visible = false
    @Binding var show: Bool
    @State var alert = false
    @State var ShowresetView = false
    @State var error = ""
    var body: some View {
        
        ZStack{
            
            ZStack(alignment: .topTrailing){
                GeometryReader{ _ in
                    VStack{
                            Image("Logo")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 300, height: 300)
                ScrollView(.vertical, showsIndicators: false){
                        TextField("Email", text: self.$email)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.email != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                        HStack(spacing: 15){
                            VStack{
                                if self.visible {
                                    TextField("Password", text: self.$pass)
                                        .autocapitalization(.none)
                                } else {
                                    SecureField("Password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                            }
                            Button(action: {
                                self.visible.toggle()
                            }){
                                Image(systemName: self.visible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(self.color)
                                    .opacity(0.9)
                            }
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.pass != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                        
                        HStack{
                            Spacer()
                            Button(action: {
                                ShowresetView = true
                            }) {
                                Text("forgot the secret number")
                                    .fontWeight(.bold)
                                    .foregroundColor(color)
                            }
                        }
                        .padding(.top, 20)
                        Button(action: {
                            self.verify()
                        }) {
                            Text("Login")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                    }
                    .padding(.horizontal ,25)
                   }
                }
                HStack{
                Button(action: {
                    self.show.toggle()
                }){
                    Text("New Registration")
                        .fontWeight(.bold)
                        .foregroundColor(color)
                }
                .padding()
               Spacer()
                    Languagebutton()
                }
            }.sheet(isPresented: $ShowresetView) {
                ForgotEmail(show: $ShowresetView)
            }
            if self.alert {
                ErrorView(alert: self.$alert, error:self.$error)
            }
        }
    }
    
    private func verify(){
        if self.email != "" && self.pass != "" {
            Auth.auth().signIn(withEmail: self.email, password: self.pass){ (res, err) in
                if err != nil {
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                print("Success")
                UserDefaults.standard.set(true, forKey: "status")
                NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
            }
            
        }else{
            self.error = "Please fill all the contents properly"
            self.alert.toggle()
        }
    }
    
    
//    private func reset() {
//        if self.email != ""{
//            Auth.auth().sendPasswordReset(withEmail: self.email){ (err) in
//                if err != nil {
//                    self.error = err!.localizedDescription
//                    self.alert.toggle()
//                    return
//                }
//                self.error = "RESET"
//                self.alert.toggle()
//            }
//        }else{
//            self.error = "Email Id is empty."
//            self.alert.toggle()
//        }
//    }
 
    
    
}

struct ForgotEmail: View {
    @StateObject var profileDate = ProfileViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State var color = Color("Color")
    @State var Name : String = ""
    @State var Email : String = ""
    @State var Password : String = ""
    @State var Rpassword : String = ""
    @State var ShohSignin = false
    @State var ShowRpassword = false
    @State var visible = false
    @Binding var show: Bool
    @State var alert = false
    @State var error = ""
    var body: some View {
        ZStack {
            VStack{
              
                
              
                VStack(spacing:1){
                 
                        
                ScrollView(.vertical, showsIndicators: false){
                    
                    HStack{
                        
                        Image("Logo")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 300, height: 300)
                    }
                    VStack(spacing:1){
                        
                       
                       
                        TextField("Email", text: self.$Email)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.Email != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                       
                    }.padding()
                    
                    
                    HStack{
                        
                        Button {
                            reset()
                            
                        } label: {
                            Text("Send password")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }.background(Color("Color"))
                            .cornerRadius(8)
                            .padding(.top, 25)
                      
                    }
                    Spacer()
                    if self.alert {
                        ErrorView(alert: self.$alert, error:self.$error)
                    }
                    
                   }
                  
                }
             
            }
        }
    }
    
    private func reset() {
        
        if self.Email != ""{
            Auth.auth().sendPasswordReset(withEmail: self.Email){ (err) in
                
                if err != nil {
                    self.error = err!.localizedDescription
                    self.alert.toggle()
                    return
                }
                
                self.error = "RESET"
                self.alert.toggle()
              
            }
        }else{
            self.error = "لا يوجد معلومات مسجلة لهذا الاميل"
            self.alert.toggle()
        }
    }
}


//struct RoundedCorners: View {
//    var color: Color = .blue
//    var tl: CGFloat = 0.0
//    var tr: CGFloat = 0.0
//    var bl: CGFloat = 0.0
//    var br: CGFloat = 0.0
//
//    var body: some View {
//        GeometryReader { geometry in
//            Path { path in
//
//                let w = geometry.size.width
//                let h = geometry.size.height
//
//                // Make sure we do not exceed the size of the rectangle
//                let tr = min(min(self.tr, h/2), w/2)
//                let tl = min(min(self.tl, h/2), w/2)
//                let bl = min(min(self.bl, h/2), w/2)
//                let br = min(min(self.br, h/2), w/2)
//
//                path.move(to: CGPoint(x: w / 2.0, y: 0))
//                path.addLine(to: CGPoint(x: w - tr, y: 0))
//                path.addArc(center: CGPoint(x: w - tr, y: tr), radius: tr, startAngle: Angle(degrees: -90), endAngle: Angle(degrees: 0), clockwise: false)
//                path.addLine(to: CGPoint(x: w, y: h - br))
//                path.addArc(center: CGPoint(x: w - br, y: h - br), radius: br, startAngle: Angle(degrees: 0), endAngle: Angle(degrees: 90), clockwise: false)
//                path.addLine(to: CGPoint(x: bl, y: h))
//                path.addArc(center: CGPoint(x: bl, y: h - bl), radius: bl, startAngle: Angle(degrees: 90), endAngle: Angle(degrees: 180), clockwise: false)
//                path.addLine(to: CGPoint(x: 0, y: tl))
//                path.addArc(center: CGPoint(x: tl, y: tl), radius: tl, startAngle: Angle(degrees: 180), endAngle: Angle(degrees: 270), clockwise: false)
//                path.closeSubpath()
//            }
//            .fill(self.color)
//        }
//    }
//}
