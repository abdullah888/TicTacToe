//
//  ProfileView.swift
//  HMH App
//
//  Created by Asrar on 14/12/1444 AH.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("hgfv")
    }
}


struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
